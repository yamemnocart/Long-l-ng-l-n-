import uuid7
import shutil
import time
from pathlib import Path
from typing import Tuple
from fastapi import UploadFile
from backend.config import settings

ALLOWED_VIDEO_EXT = {".mp4", ".mkv", ".mov", ".webm", ".avi", ".flv"}
ALLOWED_AUDIO_EXT = {".mp3", ".wav", ".m4a", ".ogg"}

def generate_task_id() -> str:
    """Tạo ID tác vụ duy nhất, có thứ tự thời gian"""
    return str(uuid7.uuid7())

def validate_file(file: UploadFile) -> Tuple[bool, str]:
    """Kiểm tra định dạng và kích thước file tải lên"""
    try:
        # Kiểm tra phần mở rộng
        ext = Path(file.filename or "").suffix.lower()
        if ext not in ALLOWED_VIDEO_EXT and ext not in ALLOWED_AUDIO_EXT:
            return False, f"Định dạng {ext} không được hỗ trợ. Hỗ trợ: {', '.join(ALLOWED_VIDEO_EXT)}"
        
        # Kiểm tra kích thước (đọc đến khi vượt giới hạn để không tải toàn bộ)
        size = 0
        for chunk in file.file:
            size += len(chunk)
            if size > settings.MAX_FILE_SIZE:
                return False, f"File quá lớn. Giới hạn: {settings.MAX_FILE_SIZE // (1024**3)}GB"
        
        # Đặt lại con trỏ file về đầu
        file.file.seek(0)
        return True, ""
        
    except Exception as e:
        return False, f"Lỗi kiểm tra file: {str(e)}"

def safe_filename(filename: str) -> str:
    """Làm sạch tên file, loại bỏ ký tự nguy hiểm"""
    name = Path(filename).stem
    ext = Path(filename).suffix.lower()
    # Chỉ giữ chữ, số, gạch dưới, gạch ngang
    safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in name)
    return f"{safe_name[:50]}{ext}"

async def save_upload_file(file: UploadFile, task_id: str) -> Path:
    """Lưu file tải lên vào thư mục uploads"""
    safe_name = safe_filename(file.filename or "video")
    save_path = settings.UPLOAD_DIR / f"{task_id}_{safe_name}"
    
    with open(save_path, "wb") as buffer:
        while chunk := await file.read(1024 * 1024):  # Đọc 1MB/lần
            buffer.write(chunk)
    
    return save_path

def cleanup_temp_files():
    """Tác vụ nền: Xóa file tạm cũ hơn thời gian lưu trữ quy định"""
    now = time.time()
    cutoff = now - settings.TEMP_RETENTION_SECONDS
    
    for directory in [settings.TEMP_DIR, settings.UPLOAD_DIR]:
        if not directory.exists():
            continue
        for item in directory.iterdir():
            try:
                if item.is_file() and item.stat().st_mtime < cutoff:
                    item.unlink()
                elif item.is_dir() and item.stat().st_mtime < cutoff:
                    shutil.rmtree(item)
            except Exception:
                continue  # Bỏ qua lỗi quyền truy cập
