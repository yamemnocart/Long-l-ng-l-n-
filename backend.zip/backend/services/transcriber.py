import whisper
from deep_translator import GoogleTranslator
from pathlib import Path
import json
import re
from typing import List, Dict, Any
from backend.config import settings

# Tải mô hình Whisper một lần (lazy loading)
_model = None

def get_whisper_model():
    global _model
    if _model is None:
        _model = whisper.load_model(
            name=settings.WHISPER_MODEL,
            device=settings.WHISPER_DEVICE,
            download_root=str(settings.TEMP_DIR / "models")
        )
    return _model

def format_timestamp(seconds: float) -> str:
    """Chuyển giây sang định dạng SRT HH:MM:SS,mmm"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds - int(seconds)) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"

def segments_to_srt(segments: List[Dict[str, Any]]) -> str:
    """Chuyển danh sách đoạn thành định dạng SRT"""
    srt_lines = []
    for i, seg in enumerate(segments, 1):
        start = format_timestamp(seg["start"])
        end = format_timestamp(seg["end"])
        text = seg["text"].strip()
        srt_lines.append(f"{i}\n{start} --> {end}\n{text}\n")
    return "\n".join(srt_lines)

def clean_text(text: str) -> str:
    """Làm sạch văn bản bản dịch"""
    text = re.sub(r'\s+', ' ', text).strip()
    text = re.sub(r'([.!?])\1+', r'\1', text)
    return text

async def transcribe_and_translate(audio_path: Path) -> Dict[str, Any]:
    """
    Nhận diện giọng nói → dịch sang tiếng Việt → xuất SRT + JSON
    Trả về: {segments: [...], srt_content: str, source_lang: str}
    """
    try:
        model = get_whisper_model()
        
        # Nhận diện với dấu thời gian từng đoạn
        result = model.transcribe(
            str(audio_path),
            word_timestamps=True,
            verbose=False
        )
        source_lang = result.get("language", "en")
        
        segments = []
        translator = GoogleTranslator(source='auto', target=settings.TRANSLATE_TARGET)
        
        for seg in result["segments"]:
            original_text = seg["text"].strip()
            if not original_text:
                continue
                
            # Dịch nếu ngôn ngữ gốc không phải tiếng Việt
            if source_lang != settings.TRANSLATE_TARGET:
                try:
                    translated = translator.translate(original_text)
                    translated = clean_text(translated) if translated else original_text
                except Exception:
                    translated = original_text
            else:
                translated = original_text
            
            segments.append({
                "id": seg["id"],
                "start": round(seg["start"], 3),
                "end": round(seg["end"], 3),
                "duration": round(seg["end"] - seg["start"], 3),
                "original": original_text,
                "text": translated,
                "words": [
                    {"word": w["word"], "start": w["start"], "end": w["end"]}
                    for w in seg.get("words", [])
                ]
            })
        
        srt_content = segments_to_srt(segments)
        
        return {
            "source_lang": source_lang,
            "segments": segments,
            "srt_content": srt_content,
            "total_segments": len(segments)
        }
        
    except Exception as e:
        raise RuntimeError(f"Lỗi nhận diện giọng nói: {str(e)}")
