import ffmpeg
from pathlib import Path
from typing import List, Dict, Any, Optional
from backend.config import settings

def extract_audio(video_path: Path, output_path: Path) -> Path:
    """Trích xuất âm thanh từ video sang WAV 16kHz mono (chuẩn Whisper)"""
    try:
        (
            ffmpeg
            .input(str(video_path))
            .output(
                str(output_path),
                acodec="pcm_s16le",
                ac=1,
                ar=16000,
                map_metadata=-1
            )
            .overwrite_output()
            .run(capture_stdout=True, capture_stderr=True)
        )
        return output_path
    except ffmpeg.Error as e:
        raise RuntimeError(f"Lỗi trích xuất âm thanh: {e.stderr.decode('utf-8', errors='ignore')}")

def get_video_info(video_path: Path) -> Dict[str, Any]:
    """Lấy thông tin độ dài, độ phân giải video"""
    try:
        probe = ffmpeg.probe(str(video_path))
        video_stream = next(s for s in probe["streams"] if s["codec_type"] == "video")
        return {
            "duration": float(probe["format"]["duration"]),
            "width": int(video_stream["width"]),
            "height": int(video_stream["height"]),
            "codec": video_stream["codec_name"]
        }
    except Exception as e:
        raise RuntimeError(f"Lỗi đọc thông tin video: {str(e)}")

def build_duck_filter(segments: List[Dict[str, Any]], duck_level: float = 0.15) -> str:
    """
    Tạo bộ lọc FFmpeg giảm âm lượng gốc khi có giọng lồng tiếng
    duck_level: Mức âm còn lại (0.15 = 15% âm lượng gốc)
    """
    filters = []
    for seg in segments:
        start = seg["start"]
        end = seg["end"]
        # Giảm âm trong khoảng thời gian đoạn lồng tiếng
        filters.append(
            f"volume='if(lt(t,{start})*gt(t,{end}),1,{duck_level})':eval=frame"
        )
    # Ghép tất cả bộ lọc (áp dụng lần lượt)
    return ",".join(filters) if filters else "volume=1"

def mix_audio_and_burn_subtitles(
    video_path: Path,
    original_audio_path: Path,
    dub_audio_path: Path,
    srt_content: str,
    segments: List[Dict[str, Any]],
    task_id: str,
    burn_subtitles: bool = True
) -> Dict[str, Any]:
    """
    1. Giảm âm gốc khi có lồng tiếng
    2. Trộn âm gốc + âm lồng
    3. Chèn phụ đề cứng vào video (nếu yêu cầu)
    4. Xuất video cuối cùng
    """
    try:
        # Lưu SRT ra file để FFmpeg đọc
        srt_path = settings.OUTPUT_DIR / f"{task_id}.srt"
        with open(srt_path, "w", encoding="utf-8") as f:
            f.write(srt_content)
        
        # Tạo bộ lọc giảm âm
        duck_filter = build_duck_filter(segments)
        
        # Đầu vào: video gốc, âm lồng
        input_video = ffmpeg.input(str(video_path))
        input_dub = ffmpeg.input(str(dub_audio_path))
        
        # Xử lý âm thanh: giảm âm gốc → trộn với lồng tiếng
        audio_ducked = input_video.audio.filter(
            "volume", duck_level if not segments else 1
        ).filter("volume", duck_filter.split("volume=")[-1] if "," not in duck_filter else duck_filter)
        
        mixed_audio = ffmpeg.filter(
            [audio_ducked, input_dub.audio],
            "amix",
            inputs=2,
            duration="first",
            dropout_transition=0
        )
        
        # Xử lý video: chèn phụ đề cứng nếu yêu cầu
        if burn_subtitles:
            # Chuẩn hóa đường dẫn SRT cho FFmpeg (thay \ bằng / trên Windows)
            srt_ffmpeg_path = str(srt_path).replace("\\", "/").replace(":", "\\:")
            video_stream = input_video.video.filter(
                "subtitles",
                filename=srt_ffmpeg_path,
                force_style="FontName=Arial,FontSize=24,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BackColour=&H80000000,Bold=1,Outline=1,Shadow=0,Alignment=2"
            )
        else:
            video_stream = input_video.video
        
        # Xuất video cuối
        final_video_path = settings.OUTPUT_DIR / f"{task_id}_final.mp4"
        (
            ffmpeg
            .output(
                video_stream,
                mixed_audio,
                str(final_video_path),
                vcodec="libx264",
                acodec="aac",
                audio_bitrate="192k",
                preset="fast",
                crf=23,
                movflags="+faststart"  # Tối ưu phát trực tuyến
            )
            .overwrite_output()
            .run(capture_stdout=True, capture_stderr=True)
        )
        
        return {
            "final_video_path": final_video_path,
            "srt_path": srt_path,
            "dub_audio_path": dub_audio_path
        }
        
    except ffmpeg.Error as e:
        raise RuntimeError(f"Lỗi xử lý video: {e.stderr.decode('utf-8', errors='ignore')[:500]}")
