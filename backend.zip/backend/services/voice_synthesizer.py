import edge_tts
import asyncio
from pathlib import Path
import ffmpeg
from typing import List, Dict, Any
from backend.config import settings

async def synthesize_segment(text: str, duration: float, output_path: Path) -> Path:
    """
    Tạo âm thanh cho 1 đoạn văn bản, điều chỉnh tốc độ để khớp thời lượng video
    """
    try:
        temp_path = output_path.with_suffix(".tmp.mp3")
        
        # Tạo âm thanh gốc với TTS
        communicate = edge_tts.Communicate(
            text=text,
            voice=settings.EDGE_TTS_VOICE,
            rate=settings.EDGE_TTS_RATE,
            pitch=settings.EDGE_TTS_PITCH
        )
        await communicate.save(str(temp_path))
        
        # Tính toán tốc độ phát lại để khớp thời lượng
        probe = ffmpeg.probe(str(temp_path))
        tts_duration = float(probe["format"]["duration"])
        
        if tts_duration <= 0:
            raise ValueError("Âm thanh TTS rỗng")
        
        # Giới hạn tốc độ trong khoảng 0.5x - 2x để không bị biến dạng giọng
        speed_ratio = min(max(tts_duration / duration, 0.5), 2.0)
        
        # Điều chỉnh tốc độ bằng FFmpeg atempo
        (
            ffmpeg
            .input(str(temp_path))
            .audio.filter("atempo", speed_ratio)
            .output(str(output_path), acodec="libmp3lame", audio_bitrate="128k")
            .overwrite_output()
            .run(capture_stdout=True, capture_stderr=True)
        )
        
        # Xóa file tạm
        temp_path.unlink(missing_ok=True)
        return output_path
        
    except Exception as e:
        raise RuntimeError(f"Lỗi tạo âm thanh đoạn '{text[:30]}...': {str(e)}")

async def synthesize_all_segments(
    segments: List[Dict[str, Any]],
    task_id: str
) -> Dict[str, Any]:
    """
    Tạo âm thanh cho tất cả các đoạn, ghép thành file lồng tiếng hoàn chỉnh
    Trả về đường dẫn file âm thanh lồng tiếng cuối cùng
    """
    try:
        task_dir = settings.TEMP_DIR / task_id
        task_dir.mkdir(parents=True, exist_ok=True)
        
        segment_files = []
        semaphore = asyncio.Semaphore(3)  # Giới hạn 3 tác vụ TTS cùng lúc
        
        async def _synth(seg):
            async with semaphore:
                seg_path = task_dir / f"seg_{seg['id']:04d}.mp3"
                return await synthesize_segment(
                    text=seg["text"],
                    duration=seg["duration"],
                    output_path=seg_path
                )
        
        # Tạo tất cả đoạn song song có giới hạn
        tasks = [_synth(seg) for seg in segments]
        segment_files = await asyncio.gather(*tasks)
        
        # Tạo file danh sách cho FFmpeg concat
        concat_file = task_dir / "concat_list.txt"
        with open(concat_file, "w", encoding="utf-8") as f:
            for sf in segment_files:
                f.write(f"file '{sf.resolve()}'\n")
        
        # Ghép tất cả đoạn thành file lồng tiếng hoàn chỉnh
        dub_path = settings.OUTPUT_DIR / f"{task_id}_dub.mp3"
        (
            ffmpeg
            .input(str(concat_file), format="concat", safe=0)
            .output(str(dub_path), acodec="libmp3lame", audio_bitrate="192k")
            .overwrite_output()
            .run(capture_stdout=True, capture_stderr=True)
        )
        
        # Dọn dẹp file tạm
        concat_file.unlink(missing_ok=True)
        for sf in segment_files:
            sf.unlink(missing_ok=True)
        
        return {
            "dub_audio_path": dub_path,
            "segment_count": len(segment_files)
        }
        
    except Exception as e:
        raise RuntimeError(f"Lỗi tổng hợp giọng nói: {str(e)}")
