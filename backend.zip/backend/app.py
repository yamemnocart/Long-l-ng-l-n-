from fastapi import FastAPI, File, UploadFile, Form, BackgroundTasks, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pathlib import Path
import asyncio
import yt_dlp
from typing import Dict, Any

from backend.config import settings
from backend.utils.helpers import (
    generate_task_id, validate_file, save_upload_file, cleanup_temp_files
)
from backend.services.video_processor import extract_audio, get_video_info, mix_audio_and_burn_subtitles
from backend.services.transcriber import transcribe_and_translate
from backend.services.voice_synthesizer import synthesize_all_segments

# Khởi tạo ứng dụng
app = FastAPI(title=settings.APP_NAME, debug=settings.DEBUG)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Bộ nhớ trạng thái tác vụ (thay bằng Redis khi mở rộng)
tasks: Dict[str, Dict[str, Any]] = {}

# Tác vụ dọn dẹp định kỳ
@app.on_event("startup")
async def startup_cleanup_scheduler():
    async def _scheduler():
        while True:
            cleanup_temp_files()
            await asyncio.sleep(settings.TEMP_RETENTION_SECONDS // 2)
    asyncio.create_task(_scheduler())

# ------------------- XỬ LÝ NỀN -------------------
async def process_video_pipeline(task_id: str, video_path: Path, burn_subs: bool = True):
    """Quy trình xử lý video hoàn chỉnh"""
    try:
        tasks[task_id]["status"] = "processing"
        tasks[task_id]["progress"] = 10
        tasks[task_id]["message"] = "Đang trích xuất âm thanh..."
        
        # Bước 1: Trích xuất âm thanh
        temp_dir = settings.TEMP_DIR / task_id
        temp_dir.mkdir(parents=True, exist_ok=True)
        audio_path = temp_dir / "audio.wav"
        extract_audio(video_path, audio_path)
        tasks[task_id]["progress"] = 25
        
        # Bước 2: Kiểm tra độ dài video
        info = get_video_info(video_path)
        if info["duration"] > settings.MAX_VIDEO_DURATION:
            raise ValueError(f"Video quá dài: {info['duration']//60} phút. Giới hạn {settings.MAX_VIDEO_DURATION//60} phút")
        tasks[task_id]["progress"] = 35
        tasks[task_id]["message"] = "Đang nhận diện và dịch giọng nói..."
        
        # Bước 3: Nhận diện + dịch
        transcribe_result = await transcribe_and_translate(audio_path)
        tasks[task_id]["segments"] = transcribe_result["segments"]
        tasks[task_id]["srt_content"] = transcribe_result["srt_content"]
        tasks[task_id]["source_lang"] = transcribe_result["source_lang"]
        tasks[task_id]["progress"] = 60
        tasks[task_id]["message"] = "Đang tạo giọng lồng tiếng Việt..."
        
        # Bước 4: Tạo lồng tiếng
        synth_result = await synthesize_all_segments(
            segments=transcribe_result["segments"],
            task_id=task_id
        )
        tasks[task_id]["progress"] = 80
        tasks[task_id]["message"] = "Đang trộn âm thanh và xuất video..."
        
        # Bước 5: Trộn âm + chèn phụ đề
        final_result = mix_audio_and_burn_subtitles(
            video_path=video_path,
            original_audio_path=audio_path,
            dub_audio_path=synth_result["dub_audio_path"],
            srt_content=transcribe_result["srt_content"],
            segments=transcribe_result["segments"],
            task_id=task_id,
            burn_subtitles=burn_subs
        )
        
        # Lưu kết quả
        tasks[task_id]["outputs"] = {
            "video": final_result["final_video_path"].name,
            "srt": final_result["srt_path"].name,
            "dub_audio": final_result["dub_audio_path"].name
        }
        tasks[task_id]["progress"] = 100
        tasks[task_id]["status"] = "completed"
        tasks[task_id]["message"] = "Hoàn thành!"
        
    except Exception as e:
        tasks[task_id]["status"] = "error"
        tasks[task_id]["message"] = str(e)
        tasks[task_id]["progress"] = 0

# ------------------- ĐIỂM KẾT NỐI API -------------------
@app.post("/api/upload")
async def upload_video(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    burn_subtitles: bool = Form(True)
):
    """Tải lên video cục bộ để xử lý"""
    task_id = generate_task_id()
    
    # Kiểm tra file
    valid, error_msg = validate_file(file)
    if not valid:
        raise HTTPException(status_code=400, detail=error_msg)
    
    # Lưu file
    video_path = await save_upload_file(file, task_id)
    
    # Khởi tạo trạng thái
    tasks[task_id] = {
        "id": task_id,
        "status": "pending",
        "progress": 0,
        "message": "Đang xếp hàng xử lý...",
        "filename": file.filename,
        "created_at": Path(video_path).stat().st_mtime
    }
    
    # Chạy xử lý nền
    background_tasks.add_task(process_video_pipeline, task_id, video_path, burn_subtitles)
    
    return JSONResponse(status_code=202, content={"task_id": task_id})

@app.post("/api/process-url")
async def process_video_url(
    background_tasks: BackgroundTasks,
    url: str = Form(...),
    burn_subtitles: bool = Form(True)
):
    """Xử lý video từ URL (YouTube, Drive...)"""
    task_id = generate_task_id()
    
    # Tải video bằng yt-dlp
    save_dir = settings.UPLOAD_DIR
    ydl_opts = {
        "outtmpl": str(save_dir / f"{task_id}_%(title).50s.%(ext)s"),
        "format": "best[ext=mp4]/best",
        "max_filesize": settings.MAX_FILE_SIZE,
        "quiet": True,
        "no_warnings": True,
        "socket_timeout": 30
    }
    
    try:
        tasks[task_id] = {
            "id": task_id,
            "status": "pending",
            "progress": 5,
            "message": "Đang tải video từ URL...",
            "url": url
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            video_path = Path(ydl.prepare_filename(info))
        
        if not video_path.exists():
            raise HTTPException(status_code=400, detail="Không thể tải video từ URL")
        
        tasks[task_id]["filename"] = video_path.name
        tasks[task_id]["progress"] = 10
        
        background_tasks.add_task(process_video_pipeline, task_id, video_path, burn_subtitles)
        return JSONResponse(status_code=202, content={"task_id": task_id})
        
    except Exception as e:
        tasks[task_id]["status"] = "error"
        tasks[task_id]["message"] = f"Lỗi tải URL: {str(e)[:200]}"
        raise HTTPException(status_code=400, detail=tasks[task_id]["message"])

@app.get("/api/status/{task_id}")
async def get_task_status(task_id: str):
    """Lấy trạng thái tiến độ xử lý"""
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Không tìm thấy tác vụ")
    
    task = tasks[task_id]
    # Loại bỏ đường dẫn tuyệt đối khỏi phản hồi
    safe_task = {k: v for k, v in task.items() if k not in ["segments", "srt_content"]}
    if task["status"] == "completed":
        safe_task["outputs"] = task.get("outputs", {})
    return safe_task

@app.get("/api/download/{file_id}")
async def download_file(file_id: str):
    """Tải xuống file kết quả"""
    file_path = settings.OUTPUT_DIR / file_id
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Không tìm thấy file")
    
    return FileResponse(
        path=str(file_path),
        filename=file_path.name,
        media_type="application/octet-stream"
    )

@app.get("/api/health")
async def health_check():
    """Kiểm tra trạng thái server"""
    return {"status": "ok", "app": settings.APP_NAME}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "backend.app:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        workers=1
    )
