from pydantic_settings import BaseSettings
from pathlib import Path
import os

class Settings(BaseSettings):
    # Cấu hình cơ bản
    APP_NAME: str = "Video Dubber AI"
    DEBUG: bool = os.getenv("DEBUG", "false").lower() == "true"
    HOST: str = "0.0.0.0"
    PORT: int = int(os.getenv("PORT", 8000))

    # Thư mục lưu trữ
    BASE_DIR: Path = Path(__file__).resolve().parent
    UPLOAD_DIR: Path = BASE_DIR / "uploads"
    OUTPUT_DIR: Path = BASE_DIR / "outputs"
    TEMP_DIR: Path = BASE_DIR / "temp"

    # Giới hạn tài nguyên
    MAX_FILE_SIZE: int = 2 * 1024 * 1024 * 1024  # 2GB
    MAX_VIDEO_DURATION: int = 3600  # 60 phút
    TEMP_RETENTION_SECONDS: int = 30 * 60  # Xóa file tạm sau 30 phút

    # Cấu hình AI
    WHISPER_MODEL: str = os.getenv("WHISPER_MODEL", "small")  # tiny/base/small/medium/large
    WHISPER_DEVICE: str = os.getenv("WHISPER_DEVICE", "cpu")  # cpu/cuda
    TRANSLATE_TARGET: str = "vi"
    EDGE_TTS_VOICE: str = os.getenv("EDGE_VOICE", "vi-VN-HoaiMyNeural")
    EDGE_TTS_RATE: str = "+0%"
    EDGE_TTS_PITCH: str = "+0Hz"

    # CORS
    CORS_ORIGINS: list = [
        "*"  # Thay bằng domain cụ thể khi triển khai sản xuất
    ]

    class Config:
        env_file = ".env"
        case_sensitive = True

# Khởi tạo thư mục tự động
settings = Settings()
for d in [settings.UPLOAD_DIR, settings.OUTPUT_DIR, settings.TEMP_DIR]:
    d.mkdir(parents=True, exist_ok=True)
